package com.example.springrabbitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringrabbitmqApplicationTests {

    @Test
    void contextLoads() {
    }

}
